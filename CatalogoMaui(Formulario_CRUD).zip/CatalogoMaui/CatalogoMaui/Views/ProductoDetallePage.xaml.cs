
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using CatalogoMaui.Models;
using CatalogoMaui.Services;

namespace CatalogoMaui.Views;

public partial class ProductoDetallePage : ContentPage, IQueryAttributable
{
    private int id;

    private string fotoFormulario = "";

    private string fotoAnterior = "";

    private string? fotoTemporal;

    private readonly List<string> fotosIncluidas = new()
    {
        "mochila.png",
        "libreta.png",
        "termo.png",
        "audifonos.png"
    };

    public ProductoDetallePage()
    {
        InitializeComponent();

        Title = "Agregar producto";

        Foto.ItemsSource = fotosIncluidas;

        Foto.SelectedIndex = 0;

        fotoFormulario = fotosIncluidas[0];

        VistaFoto.Source = FotosProducto.Resolver(fotoFormulario);
    }

    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        if (!query.TryGetValue("producto", out var dato) ||
            dato is not Producto p)
            return;

        id = p.Id;

        fotoAnterior = p.Foto;

        fotoFormulario = p.Foto;

        Title = "Editar producto";

        Nombre.Text = p.Nombre;

        Descripcion.Text = p.Descripcion;

        Detalle.Text = p.Detalle;

        Precio.Text = p.Precio.ToString(
            "0.00",
            CultureInfo.CurrentCulture
        );

        if (fotosIncluidas.Contains(p.Foto))
        {
            Foto.SelectedItem = p.Foto;
        }
        else
        {
            Foto.SelectedIndex = -1;
        }

        VistaFoto.Source = FotosProducto.Resolver(p.Foto);

        Eliminar.IsVisible = true;
    }

    private void AlCambiarFoto(object? sender, EventArgs e)
    {
        if (Foto.SelectedItem is string archivo)
        {
            FotosProducto.EliminarTemporal(fotoTemporal);

            fotoTemporal = null;

            fotoFormulario = archivo;

            VistaFoto.Source = FotosProducto.Resolver(archivo);
        }
    }

    private async void AlElegirFoto(object? sender, EventArgs e)
    {
        try
        {
            var temporal = await FotosProducto.ElegirAsync();

            if (temporal == null)
                return;

            FotosProducto.EliminarTemporal(fotoTemporal);

            fotoTemporal = temporal;

            VistaFoto.Source = temporal;
        }
        catch (Exception ex)
        {
            await DisplayAlert(
                "Error al seleccionar la imagen",
                ex.Message,
                "Aceptar"
            );
        }
    }

    private async void AlGuardar(object? sender, EventArgs e)
    {
        if (!Guardar.IsEnabled)
            return;

        var textoPrecio = Precio.Text?.Trim().Replace(',', '.');

        if (string.IsNullOrWhiteSpace(Nombre.Text) ||
            string.IsNullOrWhiteSpace(Descripcion.Text) ||
            string.IsNullOrWhiteSpace(Detalle.Text) ||
            !decimal.TryParse(
                textoPrecio,
                NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture,
                out var importe) ||
            importe < 0 ||
            importe > 99999999.99m ||
            decimal.Round(importe, 2) != importe ||
            (fotoTemporal == null &&
             string.IsNullOrWhiteSpace(fotoFormulario)))
        {
            await DisplayAlert(
                "Revisa los datos",
                "Completa los campos y escribe un precio válido de hasta dos decimales.",
                "Aceptar"
            );

            return;
        }

        string? fotoNueva = null;

        await EjecutarAsync(async () =>
        {
            try
            {
                string fotoFinal;

                if (fotoTemporal != null)
                {
                    fotoNueva = await FotosProducto.GuardarAsync(fotoTemporal);

                    fotoFinal = fotoNueva;
                }
                else
                {
                    fotoFinal = fotoFormulario;
                }

                var producto = new Producto
                {
                    Id = id,
                    Nombre = Nombre.Text.Trim(),
                    Descripcion = Descripcion.Text.Trim(),
                    Detalle = Detalle.Text.Trim(),
                    Precio = importe,
                    Foto = fotoFinal
                };

                if (id == 0)
                {
                    await ProductosSqlite.Instancia.Insertar(producto);
                }
                else if (!await ProductosSqlite.Instancia.Actualizar(producto))
                {
                    throw new InvalidOperationException(
                        "El producto ya no existe."
                    );
                }

                if (!string.Equals(fotoAnterior, fotoFinal, StringComparison.Ordinal))
                {
                    FotosProducto.EliminarPropia(fotoAnterior);
                }

                if (fotoTemporal != null)
                {
                    FotosProducto.EliminarTemporal(fotoTemporal);

                    fotoTemporal = null;
                }

                return true;
            }
            catch
            {
                if (fotoNueva != null)
                {
                    FotosProducto.EliminarPropia(fotoNueva);
                }

                throw;
            }
        });
    }

    private async void AlEliminar(object? sender, EventArgs e)
    {
        if (!Eliminar.IsEnabled || id == 0)
            return;

        await EjecutarAsync(async () =>
        {
            if (!await DisplayAlert(
                "Eliminar producto",
                "¿Deseas eliminar este producto?",
                "Eliminar",
                "Cancelar"))
            {
                return false;
            }

            if (!await ProductosSqlite.Instancia.Eliminar(id))
            {
                throw new InvalidOperationException(
                    "El producto ya no existe."
                );
            }

            FotosProducto.EliminarPropia(fotoAnterior);

            FotosProducto.EliminarTemporal(fotoTemporal);

            return true;
        });
    }

    private async Task EjecutarAsync(Func<Task<bool>> operacion)
    {
        Guardar.IsEnabled = false;

        Eliminar.IsEnabled = false;

        try
        {
            if (await operacion())
            {
                await Shell.Current.GoToAsync("..");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert(
                "No se completó la operación",
                ex.Message,
                "Aceptar"
            );
        }
        finally
        {
            Guardar.IsEnabled = true;

            Eliminar.IsEnabled = true;
        }
    }
}