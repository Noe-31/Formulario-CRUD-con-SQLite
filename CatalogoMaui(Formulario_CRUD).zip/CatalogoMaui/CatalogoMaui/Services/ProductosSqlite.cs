﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using CatalogoMaui.Models;
using SQLite;

namespace CatalogoMaui.Services;

public sealed class ProductosSqlite
{
    public static ProductosSqlite Instancia { get; } = new();

    private readonly Lazy<Task<SQLiteAsyncConnection>> conexion;

    private ProductosSqlite()
    {
        conexion = new Lazy<Task<SQLiteAsyncConnection>>(AbrirAsync);
    }

    private static async Task<SQLiteAsyncConnection> AbrirAsync()
    {
        string ruta = Path.Combine(
            FileSystem.AppDataDirectory,
            "catalogo.db3"
        );

        var db = new SQLiteAsyncConnection(ruta);

        await db.RunInTransactionAsync(c =>
        {
            c.CreateTable<Producto>();

            if (c.ExecuteScalar<int>("PRAGMA user_version") != 0)
                return;

            c.InsertAll(new[]
            {
                new Producto
                {
                    Nombre = "Mochila urbana",
                    Descripcion = "Con espacio para laptop y cuadernos.",
                    Detalle = "Mochila de uso diario con bolsillo frontal y compartimento acolchado.",
                    Precio = 499.00m,
                    Foto = "mochila.png"
                },

                new Producto
                {
                    Nombre = "Libreta A5",
                    Descripcion = "80 hojas rayadas con pasta dura.",
                    Detalle = "Libreta práctica para realizar apuntes y guardar tus notas.",
                    Precio = 89.50m,
                    Foto = "libreta.png"
                },

                new Producto
                {
                    Nombre = "Termo de acero",
                    Descripcion = "Botella reutilizable de 500 ml.",
                    Detalle = "Termo de acero con capacidad de 500 ml y tapa de rosca.",
                    Precio = 219.00m,
                    Foto = "termo.png"
                },

                new Producto
                {
                    Nombre = "Audífonos inalámbricos",
                    Descripcion = "Audífonos para escuchar música.",
                    Detalle = "Audífonos inalámbricos compactos para utilizar con dispositivos compatibles.",
                    Precio = 349.00m,
                    Foto = "audifonos.png"
                }
            }, runInTransaction: false);

            c.Execute("PRAGMA user_version = 1");
        });

        return db;
    }

    public async Task<List<Producto>> Consultar()
    {
        return await (await conexion.Value)
            .Table<Producto>()
            .OrderBy(p => p.Id)
            .ToListAsync();
    }

    public async Task<int> Insertar(Producto producto)
    {
        return await (await conexion.Value).InsertAsync(producto);
    }

    public async Task<bool> Actualizar(Producto producto)
    {
        return await (await conexion.Value).UpdateAsync(producto) > 0;
    }

    public async Task<bool> Eliminar(int id)
    {
        return await (await conexion.Value).DeleteAsync<Producto>(id) > 0;
    }
}