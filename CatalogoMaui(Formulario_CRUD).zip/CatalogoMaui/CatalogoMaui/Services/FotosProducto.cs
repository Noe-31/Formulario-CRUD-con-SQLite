﻿
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Maui.Storage;

namespace CatalogoMaui.Services;

public static class FotosProducto
{
    private const long TamanoMaximo = 15 * 1024 * 1024;

    private static string CarpetaFotos =>
        Path.Combine(FileSystem.AppDataDirectory, "fotos_productos");

    public static async Task<string?> ElegirAsync()
    {
        var archivo = await FilePicker.Default.PickAsync(
            new PickOptions
            {
                PickerTitle = "Selecciona una fotografía",
                FileTypes = FilePickerFileType.Images
            });

        if (archivo == null)
            return null;

        string extension = Path.GetExtension(archivo.FileName)
            .ToLowerInvariant();

        if (extension != ".jpg" &&
            extension != ".jpeg" &&
            extension != ".png")
        {
            throw new InvalidOperationException(
                "Selecciona una imagen JPG o PNG."
            );
        }

        string temporal = Path.Combine(
            FileSystem.CacheDirectory,
            $"vista_{Guid.NewGuid():N}{extension}"
        );

        try
        {
            await using (var origen = await archivo.OpenReadAsync())
            {
                await using (var destino = File.Create(temporal))
                {
                    byte[] buffer = new byte[81920];
                    long total = 0;
                    int leidos;

                    while ((leidos = await origen.ReadAsync(
                        buffer, 0, buffer.Length)) > 0)
                    {
                        total += leidos;

                        if (total > TamanoMaximo)
                        {
                            throw new InvalidOperationException(
                                "La imagen no puede superar los 15 MB."
                            );
                        }

                        await destino.WriteAsync(buffer, 0, leidos);
                    }
                }
            }

            return temporal;
        }
        catch
        {
            if (File.Exists(temporal))
                File.Delete(temporal);

            throw;
        }
    }

    public static async Task<string> GuardarAsync(string temporal)
    {
        Directory.CreateDirectory(CarpetaFotos);

        string extension = Path.GetExtension(temporal);

        string nombre = $"producto_{Guid.NewGuid():N}{extension}";

        string destino = Path.Combine(CarpetaFotos, nombre);

        await Task.Run(() => File.Copy(temporal, destino));

        return nombre;
    }

    public static string Resolver(string foto)
    {
        if (string.IsNullOrWhiteSpace(foto))
            return "";

        if (foto.StartsWith(
            "producto_",
            StringComparison.OrdinalIgnoreCase))
        {
            return Path.Combine(CarpetaFotos, foto);
        }

        return foto;
    }

    public static void EliminarPropia(string? foto)
    {
        if (string.IsNullOrWhiteSpace(foto) ||
            !foto.StartsWith(
                "producto_",
                StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        string ruta = Path.Combine(CarpetaFotos, foto);

        try
        {
            if (File.Exists(ruta))
                File.Delete(ruta);
        }
        catch
        {
            // La limpieza de la fotografía no debe detener el CRUD.
        }
    }

    public static void EliminarTemporal(string? ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta))
            return;

        try
        {
            if (File.Exists(ruta))
                File.Delete(ruta);
        }
        catch
        {
            // El archivo temporal podrá limpiarse posteriormente.
        }
    }
}